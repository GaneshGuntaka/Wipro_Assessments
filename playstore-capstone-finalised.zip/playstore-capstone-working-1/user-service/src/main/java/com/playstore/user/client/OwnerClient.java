package com.playstore.user.client;

import com.playstore.user.dto.AppDto;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import java.util.List;

@FeignClient(name = "owner-service", path = "/api/owners")
public interface OwnerClient {

    @GetMapping("/apps/search")
    List<AppDto> searchApps(@RequestParam("name") String name);

    @GetMapping("/apps/{id}")
    AppDto getApp(@PathVariable("id") Long id);

    @GetMapping("/apps")
    List<AppDto> appsByCategoryOrRating(@RequestParam(value = "category", required = false) String category,
                                        @RequestParam(value = "minRating", required = false) Double minRating);

    @PostMapping("/apps/{appId}/download")
    void registerDownload(@PathVariable("appId") Long appId);
}
