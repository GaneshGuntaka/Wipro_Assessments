package com.playstore.user.controller;

import com.playstore.user.dto.AppDto;
import com.playstore.user.dto.ReviewRequest;
import com.playstore.user.entity.Review;
import com.playstore.user.service.UserAppService;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/user")
@CrossOrigin
public class UserAppController {

    private final UserAppService userAppService;

    public UserAppController(UserAppService userAppService) {
        this.userAppService = userAppService;
    }

    @GetMapping("/apps/search")
    public ResponseEntity<List<AppDto>> search(@RequestParam String name) {
        return ResponseEntity.ok(userAppService.searchByName(name));
    }

    @GetMapping("/apps/{id}")
    public ResponseEntity<AppDto> getOne(@PathVariable Long id) {
        return ResponseEntity.ok(userAppService.getApp(id));
    }

    @GetMapping("/apps")
    public ResponseEntity<List<AppDto>> byCategoryOrRating(@RequestParam(required = false) String category,
                                                           @RequestParam(required = false) Double minRating) {
        if (category != null) {
            return ResponseEntity.ok(userAppService.byCategory(category));
        } else if (minRating != null) {
            return ResponseEntity.ok(userAppService.filterByRating(minRating));
        }
        return ResponseEntity.ok(userAppService.filterByRating(0.0));
    }

    @PostMapping("/apps/{appId}/reviews")
    public ResponseEntity<Review> addReview(@PathVariable Long appId,
                                            @RequestBody ReviewRequest request,
                                            Authentication authentication) {
        Long userId = 1L; // Simplified for demo; could be mapped from JWT claims
        return ResponseEntity.ok(userAppService.addReview(appId, userId, request));
    }

    @GetMapping("/apps/{appId}/reviews")
    public ResponseEntity<List<Review>> reviews(@PathVariable Long appId) {
        return ResponseEntity.ok(userAppService.reviewsForApp(appId));
    }

    @PostMapping("/apps/{appId}/download")
    public ResponseEntity<String> download(@PathVariable Long appId, Authentication authentication) {
        Long userId = 1L; // Simplified
        userAppService.downloadApp(appId, userId);
        return ResponseEntity.ok("Download registered");
    }
}
