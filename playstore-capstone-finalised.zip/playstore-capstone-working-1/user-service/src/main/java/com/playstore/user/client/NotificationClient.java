package com.playstore.user.client;

import com.playstore.user.dto.DownloadNotificationDto;
import com.playstore.user.dto.RegisterNotificationDto;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;

@FeignClient(name = "notification-service", path = "/api/notifications")
public interface NotificationClient {

    @PostMapping("/download")
    void sendDownload(@RequestBody DownloadNotificationDto dto);

    @PostMapping("/register")
    void sendRegister(@RequestBody RegisterNotificationDto dto);
}
