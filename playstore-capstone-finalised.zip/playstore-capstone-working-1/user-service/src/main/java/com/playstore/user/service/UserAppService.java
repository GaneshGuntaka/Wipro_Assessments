package com.playstore.user.service;

import com.playstore.user.client.NotificationClient;
import com.playstore.user.client.OwnerClient;
import com.playstore.user.dto.AppDto;
import com.playstore.user.dto.DownloadNotificationDto;
import com.playstore.user.dto.ReviewRequest;
import com.playstore.user.entity.Download;
import com.playstore.user.entity.Review;
import com.playstore.user.entity.User;
import com.playstore.user.exception.ResourceNotFoundException;
import com.playstore.user.repository.DownloadRepository;
import com.playstore.user.repository.ReviewRepository;
import com.playstore.user.repository.UserRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
public class UserAppService {

    private final OwnerClient ownerClient;
    private final NotificationClient notificationClient;
    private final ReviewRepository reviewRepository;
    private final DownloadRepository downloadRepository;
    private final UserRepository userRepository;

    public UserAppService(OwnerClient ownerClient,
                          NotificationClient notificationClient,
                          ReviewRepository reviewRepository,
                          DownloadRepository downloadRepository,
                          UserRepository userRepository) {
        this.ownerClient = ownerClient;
        this.notificationClient = notificationClient;
        this.reviewRepository = reviewRepository;
        this.downloadRepository = downloadRepository;
        this.userRepository = userRepository;
    }

    public List<AppDto> searchByName(String name) {
        return ownerClient.searchApps(name);
    }

    public AppDto getApp(Long id) {
        return ownerClient.getApp(id);
    }

    public List<AppDto> byCategory(String category) {
        return ownerClient.appsByCategoryOrRating(category, null);
    }

    public List<AppDto> filterByRating(Double rating) {
        return ownerClient.appsByCategoryOrRating(null, rating);
    }

    @Transactional
    public Review addReview(Long appId, Long userId, ReviewRequest request) {
        User user = userRepository.findById(userId)
                .orElseThrow(() -> new ResourceNotFoundException("User not found"));
        Review review = new Review(appId, userId, user.getName(), request.getRating(), request.getComment());
        return reviewRepository.save(review);
    }

    public List<Review> reviewsForApp(Long appId) {
        return reviewRepository.findByAppId(appId);
    }

    @Transactional
    public void downloadApp(Long appId, Long userId) {
        ownerClient.registerDownload(appId);
        Download download = new Download(appId, userId);
        downloadRepository.save(download);
        AppDto app = ownerClient.getApp(appId);
        DownloadNotificationDto dto = new DownloadNotificationDto();
        dto.setAppId(appId);
        dto.setAppName(app.getName());
        dto.setOwnerEmail("ganeshreddy7721@gmail.com");
        User user = userRepository.findById(userId)
                .orElseThrow(() -> new ResourceNotFoundException("User not found"));
        dto.setUserEmail(user.getEmail());
        notificationClient.sendDownload(dto);
    }
}
