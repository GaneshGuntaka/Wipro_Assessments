package com.playstore.owner.dto;

public class DownloadCountResponse {
    private Long appId;
    private long downloadCount;

    public DownloadCountResponse() {}

    public DownloadCountResponse(Long appId, long downloadCount) {
        this.appId = appId;
        this.downloadCount = downloadCount;
    }

    public Long getAppId() { return appId; }
    public void setAppId(Long appId) { this.appId = appId; }

    public long getDownloadCount() { return downloadCount; }
    public void setDownloadCount(long downloadCount) { this.downloadCount = downloadCount; }
}
