package com.playstore.owner.service;

import com.playstore.owner.dto.*;
import com.playstore.owner.entity.App;
import com.playstore.owner.entity.Owner;
import com.playstore.owner.exception.ResourceNotFoundException;
import com.playstore.owner.repository.AppRepository;
import com.playstore.owner.repository.OwnerRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDate;
import java.util.List;
import java.util.stream.Collectors;

@Service
public class OwnerService {

    private final OwnerRepository ownerRepository;
    private final AppRepository appRepository;

    public OwnerService(OwnerRepository ownerRepository, AppRepository appRepository) {
        this.ownerRepository = ownerRepository;
        this.appRepository = appRepository;
    }

    public OwnerLoginResponse registerOwner(OwnerRegisterRequest request) {
        Owner owner = new Owner(request.getName(), request.getEmail(), request.getPassword());
        owner = ownerRepository.save(owner);
        OwnerLoginResponse resp = new OwnerLoginResponse();
        resp.setOwnerId(owner.getId());
        resp.setName(owner.getName());
        resp.setEmail(owner.getEmail());
        resp.setMessage("Owner registered successfully");
        return resp;
    }

    public OwnerLoginResponse login(LoginRequest request) {
        Owner owner = ownerRepository.findByEmail(request.getEmail())
                .filter(Owner::isActive)
                .orElseThrow(() -> new ResourceNotFoundException("Owner not found"));
        if (!owner.getPassword().equals(request.getPassword())) {
            throw new ResourceNotFoundException("Invalid credentials");
        }
        OwnerLoginResponse resp = new OwnerLoginResponse();
        resp.setOwnerId(owner.getId());
        resp.setName(owner.getName());
        resp.setEmail(owner.getEmail());
        resp.setMessage("Login successful");
        return resp;
    }

    public AppDto createApp(Long ownerId, AppDto dto) {
        Owner owner = ownerRepository.findById(ownerId)
                .orElseThrow(() -> new ResourceNotFoundException("Owner not found"));
        App app = new App();
        app.setName(dto.getName());
        app.setDescription(dto.getDescription());
        app.setReleaseDate(dto.getReleaseDate() != null ? dto.getReleaseDate() : LocalDate.now());
        app.setVersion(dto.getVersion());
        app.setRating(dto.getRating());
        app.setGenre(dto.getGenre());
        app.setCategory(dto.getCategory());
        app.setVisible(dto.isVisible());
        app.setOwner(owner);
        app = appRepository.save(app);
        return toDto(app);
    }

    public AppDto updateApp(Long ownerId, Long appId, UpdateAppRequest req) {
        App app = appRepository.findById(appId)
                .orElseThrow(() -> new ResourceNotFoundException("App not found"));
        if (req.getDescription() != null) app.setDescription(req.getDescription());
        if (req.getVersion() != null) app.setVersion(req.getVersion());
        if (req.getVisible() != null) app.setVisible(req.getVisible());
        app = appRepository.save(app);
        return toDto(app);
    }

    public void deleteApp(Long ownerId, Long appId) {
        App app = appRepository.findById(appId)
                .orElseThrow(() -> new ResourceNotFoundException("App not found"));
        appRepository.delete(app);
    }

    public List<AppDto> listOwnerApps(Long ownerId) {
        return appRepository.findAll().stream()
                .filter(a -> a.getOwner() != null && a.getOwner().getId().equals(ownerId))
                .map(this::toDto)
                .collect(Collectors.toList());
    }

    public List<AppDto> searchByName(String name) {
        return appRepository.findByNameContainingIgnoreCase(name).stream()
                .filter(App::isVisible)
                .map(this::toDto)
                .collect(Collectors.toList());
    }

    public List<AppDto> byCategory(String category) {
        return appRepository.findByCategoryIgnoreCaseAndVisibleTrue(category).stream()
                .map(this::toDto)
                .collect(Collectors.toList());
    }

    public List<AppDto> filterByRating(double rating) {
        return appRepository.findByRatingGreaterThanEqualAndVisibleTrue(rating).stream()
                .map(this::toDto)
                .collect(Collectors.toList());
    }

    public AppDto getApp(Long id) {
        App app = appRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("App not found"));
        return toDto(app);
    }

    @Transactional
    public DownloadCountResponse incrementDownload(Long appId) {
        App app = appRepository.findById(appId)
                .orElseThrow(() -> new ResourceNotFoundException("App not found"));
        app.setDownloadCount(app.getDownloadCount() + 1);
        return new DownloadCountResponse(app.getId(), app.getDownloadCount());
    }

    private AppDto toDto(App app) {
        AppDto dto = new AppDto();
        dto.setId(app.getId());
        dto.setName(app.getName());
        dto.setDescription(app.getDescription());
        dto.setReleaseDate(app.getReleaseDate());
        dto.setVersion(app.getVersion());
        dto.setRating(app.getRating());
        dto.setGenre(app.getGenre());
        dto.setCategory(app.getCategory());
        dto.setVisible(app.isVisible());
        dto.setDownloadCount(app.getDownloadCount());
        return dto;
    }
}
