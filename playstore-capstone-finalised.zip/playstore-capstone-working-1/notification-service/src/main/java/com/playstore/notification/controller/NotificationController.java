package com.playstore.notification.controller;

import com.playstore.notification.dto.DownloadNotificationRequest;
import com.playstore.notification.dto.RegisterNotificationRequest;
import com.playstore.notification.dto.UpdateNotificationRequest;
import com.playstore.notification.service.NotificationService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/notifications")
@CrossOrigin
public class NotificationController {

    private final NotificationService notificationService;

    public NotificationController(NotificationService notificationService) {
        this.notificationService = notificationService;
    }

    

    @PostMapping("/register")
    public ResponseEntity<String> handleRegister(@RequestBody RegisterNotificationRequest request) {
        notificationService.notifyRegister(request);
        return ResponseEntity.ok("Registration notification stored");
    }

    @PostMapping("/download")
    public ResponseEntity<String> handleDownload(@RequestBody DownloadNotificationRequest request) {
        notificationService.notifyDownload(request);
        return ResponseEntity.ok("Download notification stored");
    }

    @PostMapping("/update")
    public ResponseEntity<String> handleUpdate(@RequestBody UpdateNotificationRequest request) {
        notificationService.notifyUpdate(request);
        return ResponseEntity.ok("Update notification stored");
    }


    @GetMapping("/logs")
    public ResponseEntity<?> getLogs() {
        return ResponseEntity.ok(notificationService.getRecentLogs());
    }

}
