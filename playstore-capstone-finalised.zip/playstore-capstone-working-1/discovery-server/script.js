const USER_BASE = "http://localhost:8081/api";
const OWNER_BASE = "http://localhost:8082/api";
const TOKEN_KEY = "ganesh_playstore_token";

function homeSearchApps() {
    const q = document.getElementById("homeSearch").value;
    if (!q) return;
    fetch(`${USER_BASE}/user/apps/search?name=${encodeURIComponent(q)}`)
        .then(r => r.json())
        .then(renderResults)
        .catch(console.error);
}

function openCategory(cat) {
    fetch(`${USER_BASE}/user/apps?category=${encodeURIComponent(cat)}`)
        .then(r => r.json())
        .then(renderResults)
        .catch(console.error);
}

function renderResults(apps) {
    const c = document.getElementById("resultsContainer");
    if (!c) return;
    c.innerHTML = "";
    if (!apps || apps.length === 0) {
        c.innerHTML = "<p>No apps found.</p>";
        return;
    }
    apps.forEach(a => {
        const div = document.createElement("div");
        div.className = "card";
        div.innerHTML = `
            <h3>${a.name}</h3>
            <p>${a.description || ""}</p>
            <div class="meta">
                <div>Rating: ${a.rating ?? 0}</div>
                <div>Category: ${a.category || "-"}</div>
                <div>Version: ${a.version || "-"}</div>
            </div>
        `;
        c.appendChild(div);
    });
}

function userRegister(ev) {
    ev.preventDefault();
    const body = {
        name: document.getElementById("userRegName").value,
        email: document.getElementById("userRegEmail").value,
        password: document.getElementById("userRegPassword").value
    };
    fetch(`${USER_BASE}/auth/register`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(body)
    })
        .then(r => r.json())
        .then(data => {
            localStorage.setItem(TOKEN_KEY, data.token);
            document.getElementById("userRegMsg").textContent = "Registered successfully!";
        })
        .catch(() => document.getElementById("userRegMsg").textContent = "Error registering");
}

function userLogin(ev) {
    ev.preventDefault();
    const body = {
        email: document.getElementById("userLoginEmail").value,
        password: document.getElementById("userLoginPassword").value
    };
    fetch(`${USER_BASE}/auth/login`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(body)
    })
        .then(r => r.json())
        .then(data => {
            localStorage.setItem(TOKEN_KEY, data.token);
            document.getElementById("userLoginMsg").textContent = "Login successful!";
        })
        .catch(() => document.getElementById("userLoginMsg").textContent = "Invalid credentials");
}

function ownerLogin(ev) {
    ev.preventDefault();
    const body = {
        email: document.getElementById("ownerEmail").value,
        password: document.getElementById("ownerPassword").value
    };
    fetch(`${OWNER_BASE}/owners/login`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(body)
    })
        .then(r => r.json())
        .then(data => {
            localStorage.setItem("ganesh_owner_id", data.ownerId);
            window.location.href = "owner-dashboard.html";
        })
        .catch(() => document.getElementById("ownerLoginMsg").textContent = "Invalid owner credentials");
}

function showCreateApp() {
    document.getElementById("createAppSection").classList.remove("hidden");
}
function hideCreateApp() {
    document.getElementById("createAppSection").classList.add("hidden");
}

function createApp() {
    const ownerId = localStorage.getItem("ganesh_owner_id");
    if (!ownerId) {
        alert("Please login as owner again.");
        return;
    }
    const body = {
        name: document.getElementById("appName").value,
        description: document.getElementById("appDescription").value,
        version: document.getElementById("appVersion").value,
        genre: document.getElementById("appGenre").value,
        category: document.getElementById("appCategory").value,
        visible: document.getElementById("appVisible").checked,
        rating: 0.0
    };
    fetch(`${OWNER_BASE}/owners/${ownerId}/apps`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(body)
    })
        .then(r => r.json())
        .then(() => {
            document.getElementById("createAppMsg").textContent = "App saved!";
            loadOwnerApps();
        })
        .catch(() => document.getElementById("createAppMsg").textContent = "Error saving app");
}

function loadOwnerApps() {
    const ownerId = localStorage.getItem("ganesh_owner_id");
    if (!ownerId) return;
    fetch(`${OWNER_BASE}/owners/${ownerId}/apps`)
        .then(r => r.json())
        .then(apps => {
            const container = document.getElementById("ownerApps");
            if (!container) return;
            container.innerHTML = "";
            apps.forEach(a => {
                const div = document.createElement("div");
                div.className = "card";
                div.innerHTML = `
                    <h3>${a.name}</h3>
                    <p>${a.description || ""}</p>
                    <div class="meta">Downloads: ${a.downloadCount}</div>
                `;
                container.appendChild(div);
            });
        });
}

if (window.location.pathname.endsWith("owner-dashboard.html")) {
    loadOwnerApps();
}
