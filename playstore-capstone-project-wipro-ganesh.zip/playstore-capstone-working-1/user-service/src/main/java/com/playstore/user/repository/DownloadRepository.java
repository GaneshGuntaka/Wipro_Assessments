package com.playstore.user.repository;

import com.playstore.user.entity.Download;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface DownloadRepository extends JpaRepository<Download, Long> {
    List<Download> findByUserId(Long userId);
    long countByAppId(Long appId);
}
