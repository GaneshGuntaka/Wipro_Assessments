package com.playstore.owner.client;

import com.playstore.owner.dto.UpdateNotificationDto;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;

@FeignClient(name = "notification-service", path = "/api/notifications")
public interface NotificationClient {

    @PostMapping("/update")
    void sendUpdate(@RequestBody UpdateNotificationDto dto);
}
