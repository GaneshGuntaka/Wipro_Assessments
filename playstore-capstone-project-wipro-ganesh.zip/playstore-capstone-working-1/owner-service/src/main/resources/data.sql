INSERT INTO OWNER (id, name, email, password, active) VALUES
 (1, 'Ganesh Admin', 'ganeshreddy7721@gmail.com', 'admin123', TRUE);

INSERT INTO APP (id, name, description, release_date, version, rating, genre, category, visible, download_count, owner_id) VALUES
 (1, 'MetroRide', 'Smart metro ticket booking and live train status.', CURRENT_DATE, '1.0.0', 4.5, 'Travel', 'travel', TRUE, 1200, 1),
 (2, 'FitBuddy', 'Daily workout planner with step tracking and nutrition tips.', CURRENT_DATE, '2.1.0', 4.2, 'Health', 'health', TRUE, 800, 1),
 (3, 'StyleSnap', 'Try-on outfits virtually and track your wardrobe.', CURRENT_DATE, '0.9.5', 4.0, 'Fashion', 'fashion', TRUE, 450, 1);
