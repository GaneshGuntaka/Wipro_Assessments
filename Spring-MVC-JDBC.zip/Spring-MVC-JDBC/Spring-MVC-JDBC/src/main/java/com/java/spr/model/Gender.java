package com.java.spr.model;

public enum Gender {
	MALE, FEMALE
}
