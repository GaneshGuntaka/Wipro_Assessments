# MetroRide Kubernetes & KEDA Submission

This package includes Kubernetes manifests, KEDA ScaledObject mock, SonarQube properties, and scripts.

## SonarQube (Code Quality)
- `sonar-project.properties` provided.
- To run SonarQube locally (Docker):
  1. `docker-compose -f docker-compose-sonarqube.yml up -d`
  2. Access dashboard at http://localhost:9000 (default credentials: admin/admin)
  3. Run scanner:
     `sonar-scanner -Dsonar.projectKey=metro -Dsonar.sources=project_src/src`

Files:
- `sonar-project.properties`
- `docker-compose-sonarqube.yml`

## Kubernetes
Apply manifests:
kubectl apply -f k8s/deployment.yaml
kubectl apply -f k8s/service.yaml
kubectl apply -f k8s/hpa.yaml
kubectl apply -f k8s/keda-scaledobject.yaml

sql
Copy code
Check pods and services:
kubectl get pods
kubectl get svc

bash
Copy code

## Autoscaling (HPA)
- HPA configured in `k8s/hpa.yaml` targeting CPU utilization 50%.

## KEDA (Event-driven)
- Mock `k8s/keda-scaledobject.yaml` shows structure for KEDA ScaledObject.
- For real KEDA:
  - Install via Helm: `helm repo add kedacore https://kedacore.github.io/charts`
  - `helm install keda kedacore/keda --namespace keda --create-namespace`

## Deployment strategies
- Rolling update: `k8s/rolling-update.yaml` uses RollingUpdate with maxUnavailable=1, maxSurge=1.
- Blue/Green: `k8s/blue-green.yaml` shows two deployments (blue & green) and service selector switch.
