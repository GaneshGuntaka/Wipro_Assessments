// ==========================
// CONFIG & CONSTANTS
// ==========================
const USER_BASE = "http://localhost:8081/api";
const OWNER_BASE = "http://localhost:8082/api";
const TOKEN_KEY = "ganesh_playstore_token";
const CURRENT_USER_EMAIL_KEY = "ganesh_current_user_email";
const OWNER_ID_KEY = "ganesh_owner_id";

const USERS_STORE_KEY = "ganesh_users";            // [{name, email}]
const INSTALLS_STORE_KEY = "ganesh_installs";      // { [email]: [appKey, ...] }

// Helpers for localStorage JSON
function readJson(key, fallback) {
    try {
        const raw = localStorage.getItem(key);
        return raw ? JSON.parse(raw) : fallback;
    } catch {
        return fallback;
    }
}
function writeJson(key, value) {
    localStorage.setItem(key, JSON.stringify(value));
}

// ==========================
// USER REGISTER & LOGIN
// ==========================
function userRegister(ev) {
    ev.preventDefault();
    const body = {
        name: document.getElementById("userRegName").value,
        email: document.getElementById("userRegEmail").value,
        password: document.getElementById("userRegPassword").value
    };

    fetch(`${USER_BASE}/auth/register`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(body)
    })
        .then(r => r.json())
        .then(data => {
            if (data.token) {
                localStorage.setItem(TOKEN_KEY, data.token);
            }

            // Store basic user info locally for admin dashboard & installs
            const users = readJson(USERS_STORE_KEY, []);
            if (!users.find(u => u.email === body.email)) {
                users.push({ name: body.name, email: body.email });
                writeJson(USERS_STORE_KEY, users);
            }

            const msg = document.getElementById("userRegMsg");
            msg.textContent = "Registered successfully! Please login with your credentials.";
        })
        .catch(() => {
            document.getElementById("userRegMsg").textContent = "Error registering. Please try again.";
        });
}

function userLogin(ev) {
    ev.preventDefault();
    const email = document.getElementById("userLoginEmail").value;
    const body = {
        email: email,
        password: document.getElementById("userLoginPassword").value
    };

    fetch(`${USER_BASE}/auth/login`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(body)
    })
        .then(r => {
            if (!r.ok) {
                throw new Error("Invalid credentials");
            }
            return r.json();
        })
        .then(data => {
            if (data.token) {
                localStorage.setItem(TOKEN_KEY, data.token);
            }
            localStorage.setItem(CURRENT_USER_EMAIL_KEY, email);

            // Ensure user exists in local store
            const users = readJson(USERS_STORE_KEY, []);
            if (!users.find(u => u.email === email)) {
                users.push({ name: data.name || email.split("@")[0], email });
                writeJson(USERS_STORE_KEY, users);
            }

            // Redirect to user dashboard
            window.location.href = "user-dashboard.html";
        })
        .catch(() => {
            document.getElementById("userLoginMsg").textContent = "Invalid credentials. Please try again.";
        });
}

function userLogout() {
    localStorage.removeItem(TOKEN_KEY);
    localStorage.removeItem(CURRENT_USER_EMAIL_KEY);
    window.location.href = "index.html";
}

// ==========================
// USER DASHBOARD
// ==========================
let _allAppsCache = [];

function getAppKey(app) {
    return app.id ?? app.appId ?? app.name;
}

function loadUserDashboard() {
    const email = localStorage.getItem(CURRENT_USER_EMAIL_KEY);
    if (!email) {
        window.location.href = "user-login.html";
        return;
    }

    const users = readJson(USERS_STORE_KEY, []);
    const user = users.find(u => u.email === email);
    const welcome = document.getElementById("userWelcomeTitle");
    if (welcome) {
        welcome.textContent = `Welcome, ${user ? user.name : email}`;
    }

    // Load apps for user view
    fetch(`${USER_BASE}/user/apps`)
        .then(r => r.json())
        .then(apps => {
            _allAppsCache = Array.isArray(apps) ? apps : [];
            renderUserApps(email);
        })
        .catch(() => {
            document.getElementById("userAppsMsg").textContent = "Unable to load apps.";
        });
}

function renderUserApps(email) {
    const installsMap = readJson(INSTALLS_STORE_KEY, {});
    const installedKeys = installsMap[email] || [];

    const availableContainer = document.getElementById("availableApps");
    const installedContainer = document.getElementById("installedApps");

    availableContainer.innerHTML = "";
    installedContainer.innerHTML = "";

    if (_allAppsCache.length === 0) {
        availableContainer.innerHTML = "<p>No apps available.</p>";
        return;
    }

    _allAppsCache.forEach(app => {
        const key = getAppKey(app);
        const isInstalled = installedKeys.includes(key);

        const card = document.createElement("div");
        card.className = "card app-card";
        card.innerHTML = `
            <div class="card-header">
                <h3>${app.name}</h3>
                <span class="badge">${app.genre || app.category || "General"}</span>
            </div>
            <p>${app.description || ""}</p>
            <div class="meta-row">
                <span class="meta-item">Downloads: ${app.downloadCount ?? 0}</span>
                <span class="meta-item">Rating: ${renderStars(app.rating ?? 0)}</span>
            </div>
            <div class="card-actions">
                ${isInstalled
                    ? `<button class="btn secondary small" disabled>Installed</button>`
                    : `<button class="btn primary small" onclick="installApp('${key}')">Install</button>`
                }
            </div>
        `;
        availableContainer.appendChild(card);

        if (isInstalled) {
            const instCard = document.createElement("div");
            instCard.className = "card app-card";
            instCard.innerHTML = `
                <div class="card-header">
                    <h3>${app.name}</h3>
                    <span class="badge subtle">${app.genre || app.category || "General"}</span>
                </div>
                <div class="meta-row">
                    <span class="meta-item">Version: ${app.version || "-"}</span>
                    <span class="meta-item">Rating: ${renderStars(app.rating ?? 0)}</span>
                </div>
            `;
            installedContainer.appendChild(instCard);
        }
    });
}

function installApp(appKey) {
    const email = localStorage.getItem(CURRENT_USER_EMAIL_KEY);
    if (!email) {
        window.location.href = "user-login.html";
        return;
    }

    const installsMap = readJson(INSTALLS_STORE_KEY, {});
    const installed = installsMap[email] || [];
    if (!installed.includes(appKey)) {
        installed.push(appKey);
        installsMap[email] = installed;
        writeJson(INSTALLS_STORE_KEY, installsMap);
    }

    const msg = document.getElementById("userAppsMsg");
    if (msg) {
        msg.textContent = "Download successful! App added to your installed list.";
    }

    renderUserApps(email);
}

// Render rating as stars
function renderStars(r) {
    const rating = Math.max(0, Math.min(5, r));
    const full = "★".repeat(Math.floor(rating));
    const empty = "☆".repeat(5 - Math.floor(rating));
    return `<span class="stars">${full}${empty}</span>`;
}

// ==========================
// ADMIN LOGIN
// ==========================
function ownerLogin(ev) {
    ev.preventDefault();
    const body = {
        email: document.getElementById("ownerEmail").value,
        password: document.getElementById("ownerPassword").value
    };

    fetch(`${OWNER_BASE}/owners/login`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(body)
    })
        .then(r => {
            if (!r.ok) {
                throw new Error("Invalid admin credentials");
            }
            return r.json();
        })
        .then(data => {
            localStorage.setItem(OWNER_ID_KEY, data.ownerId || "1");
            window.location.href = "owner-dashboard.html";
        })
        .catch(() => {
            document.getElementById("ownerLoginMsg").textContent = "Invalid admin credentials.";
        });
}

function adminLogout() {
    localStorage.removeItem(OWNER_ID_KEY);
    window.location.href = "index.html";
}

// ==========================
// ADMIN DASHBOARD
// ==========================
function showCreateApp() {
    document.getElementById("createAppSection").classList.remove("hidden");
}
function hideCreateApp() {
    document.getElementById("createAppSection").classList.add("hidden");
}

function createApp() {
    const ownerId = localStorage.getItem(OWNER_ID_KEY);
    if (!ownerId) {
        alert("Please login as admin again.");
        return;
    }
    const body = {
        name: document.getElementById("appName").value,
        description: document.getElementById("appDescription").value,
        version: document.getElementById("appVersion").value,
        genre: document.getElementById("appGenre").value,
        owner: document.getElementById("appOwner").value,
        category: document.getElementById("appCategory").value,
        type: document.getElementById("appType").value,
        visible: document.getElementById("appVisible").checked,
        rating: parseFloat(document.getElementById("appRating").value) || 0.0,
        downloadCount: 0
    };

    fetch(`${OWNER_BASE}/owners/${ownerId}/apps`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(body)
    })
        .then(r => r.json())
        .then(() => {
            document.getElementById("createAppMsg").textContent = "App saved successfully!";
            loadAdminDashboard(); // refresh stats & app list
        })
        .catch(() => {
            document.getElementById("createAppMsg").textContent = "Error saving app.";
        });
}

function loadAdminDashboard() {
    const ownerId = localStorage.getItem(OWNER_ID_KEY);
    if (!ownerId) {
        window.location.href = "owner-login.html";
        return;
    }

    // Load apps created by admin
    fetch(`${OWNER_BASE}/owners/${ownerId}/apps`)
        .then(r => r.json())
        .then(apps => {
            if (!Array.isArray(apps)) apps = [];
            _allAppsCache = apps;

            renderAdminApps(apps);
            updateAdminStats(apps);
            renderAdminUserProfiles(apps);
        })
        .catch(() => {
            renderAdminUserProfiles([]);
        });
}

function renderAdminApps(apps) {
    const container = document.getElementById("ownerApps");
    if (!container) return;

    container.innerHTML = "";
    if (!apps || apps.length === 0) {
        container.innerHTML = "<p>No apps created yet.</p>";
        return;
    }

    apps.forEach(a => {
        const card = document.createElement("div");
        card.className = "card app-card";
        card.innerHTML = `
            <div class="card-header">
                <h3>${a.name}</h3>
                <span class="badge">${a.genre || a.category || "General"}</span>
            </div>
            <p>${a.description || ""}</p>
            <div class="meta-row">
                <span class="meta-item">Owner: ${a.owner || "Ganesh"}</span>
                <span class="meta-item">${(a.type || "free").toUpperCase()}</span>
            </div>
            <div class="meta-row">
                <span class="meta-item">Downloads: ${a.downloadCount ?? 0}</span>
                <span class="meta-item">Rating: ${renderStars(a.rating ?? 0)}</span>
            </div>
        `;
        container.appendChild(card);
    });
}

function updateAdminStats(apps) {
    const users = readJson(USERS_STORE_KEY, []);
    const installsMap = readJson(INSTALLS_STORE_KEY, {});

    const totalApps = apps.length;
    const totalUsers = users.length;

    // Sum downloads from apps + local installs as extra
    let totalDownloads = 0;
    apps.forEach(a => {
        totalDownloads += a.downloadCount ?? 0;
    });
    Object.values(installsMap).forEach(list => {
        totalDownloads += list.length;
    });

    document.getElementById("statApps").textContent = totalApps;
    document.getElementById("statUsers").textContent = totalUsers;
    document.getElementById("statDownloads").textContent = totalDownloads;
}

function renderAdminUserProfiles(apps) {
    const container = document.getElementById("adminUserProfiles");
    if (!container) return;

    const users = readJson(USERS_STORE_KEY, []);
    const installsMap = readJson(INSTALLS_STORE_KEY, {});

    if (users.length === 0) {
        container.innerHTML = "<p>No users registered yet.</p>";
        return;
    }

    // Build map of appKey -> name for display
    const appNameMap = {};
    apps.forEach(a => {
        appNameMap[getAppKey(a)] = a.name;
    });

    let html = `
        <div class="profiles-header">
            <span>Name</span>
            <span>Email</span>
            <span>Installed Apps</span>
        </div>
    `;

    users.forEach(u => {
        const installedKeys = installsMap[u.email] || [];
        const appNames = installedKeys.map(k => appNameMap[k] || k);
        html += `
            <div class="profiles-row">
                <span>${u.name}</span>
                <span>${u.email}</span>
                <span>${appNames.length ? appNames.join(", ") : "None"}</span>
            </div>
        `;
    });

    container.innerHTML = html;
}

// ==========================
// PAGE-SPECIFIC AUTO INIT
// ==========================
(function initPage() {
    const path = window.location.pathname;

    if (path.endsWith("user-dashboard.html")) {
        loadUserDashboard();
    }
    if (path.endsWith("owner-dashboard.html")) {
        loadAdminDashboard();
    }
})();
