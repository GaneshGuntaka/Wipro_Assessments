package com.playstore.notification.service;

import com.playstore.notification.dto.DownloadNotificationRequest;
import com.playstore.notification.dto.UpdateNotificationRequest;
import com.playstore.notification.entity.NotificationLog;
import com.playstore.notification.repository.NotificationLogRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
public class NotificationService {

    private final NotificationLogRepository repository;

    public NotificationService(NotificationLogRepository repository) {
        this.repository = repository;
    }

    @Transactional
    public void notifyDownload(DownloadNotificationRequest request) {
        String subject = "App downloaded: " + request.getAppName();
        String body = "User " + request.getUserEmail() + " downloaded your app: " + request.getAppName();
        NotificationLog log = new NotificationLog("DOWNLOAD", request.getOwnerEmail(), subject, body);
        repository.save(log);
    }

    @Transactional
    public void notifyUpdate(UpdateNotificationRequest request) {
        String subject = "App updated: " + request.getAppName();
        String body = "New version " + request.getVersion() + " is available for app: " + request.getAppName();
        String email = request.getUserEmail() != null ? request.getUserEmail() : "ganeshreddy7721@gmail.com";
        NotificationLog log = new NotificationLog("UPDATE", email, subject, body);
        repository.save(log);
    }
}
