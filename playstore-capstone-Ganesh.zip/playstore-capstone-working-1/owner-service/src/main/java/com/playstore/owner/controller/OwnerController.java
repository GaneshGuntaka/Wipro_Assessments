package com.playstore.owner.controller;

import com.playstore.owner.dto.*;
import com.playstore.owner.service.OwnerService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/owners")
@CrossOrigin
public class OwnerController {

    private final OwnerService ownerService;

    public OwnerController(OwnerService ownerService) {
        this.ownerService = ownerService;
    }

    @PostMapping("/register")
    public ResponseEntity<OwnerLoginResponse> register(@RequestBody OwnerRegisterRequest request) {
        return ResponseEntity.ok(ownerService.registerOwner(request));
    }

    @PostMapping("/login")
    public ResponseEntity<OwnerLoginResponse> login(@RequestBody LoginRequest request) {
        return ResponseEntity.ok(ownerService.login(request));
    }

    @PostMapping("/{ownerId}/apps")
    public ResponseEntity<AppDto> createApp(@PathVariable Long ownerId, @RequestBody AppDto dto) {
        return ResponseEntity.ok(ownerService.createApp(ownerId, dto));
    }

    @PutMapping("/{ownerId}/apps/{appId}")
    public ResponseEntity<AppDto> updateApp(@PathVariable Long ownerId, @PathVariable Long appId,
                                            @RequestBody UpdateAppRequest req) {
        return ResponseEntity.ok(ownerService.updateApp(ownerId, appId, req));
    }

    @DeleteMapping("/{ownerId}/apps/{appId}")
    public ResponseEntity<Void> deleteApp(@PathVariable Long ownerId, @PathVariable Long appId) {
        ownerService.deleteApp(ownerId, appId);
        return ResponseEntity.noContent().build();
    }

    @GetMapping("/{ownerId}/apps")
    public ResponseEntity<List<AppDto>> ownerApps(@PathVariable Long ownerId) {
        return ResponseEntity.ok(ownerService.listOwnerApps(ownerId));
    }

    // For user-service to consume
    @GetMapping("/apps/search")
    public ResponseEntity<List<AppDto>> search(@RequestParam String name) {
        return ResponseEntity.ok(ownerService.searchByName(name));
    }

    @GetMapping("/apps/{id}")
    public ResponseEntity<AppDto> getOne(@PathVariable Long id) {
        return ResponseEntity.ok(ownerService.getApp(id));
    }

    @GetMapping("/apps")
    public ResponseEntity<List<AppDto>> byCategory(@RequestParam(required = false) String category,
                                                   @RequestParam(required = false) Double minRating) {
        if (category != null) {
            return ResponseEntity.ok(ownerService.byCategory(category));
        } else if (minRating != null) {
            return ResponseEntity.ok(ownerService.filterByRating(minRating));
        }
        return ResponseEntity.ok(ownerService.filterByRating(0));
    }

    @PostMapping("/apps/{appId}/download")
    public ResponseEntity<DownloadCountResponse> incrementDownload(@PathVariable Long appId) {
        return ResponseEntity.ok(ownerService.incrementDownload(appId));
    }
}
